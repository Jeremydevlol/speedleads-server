#!/bin/bash
echo "🚀 Iniciando Uniclick API..."
export NODE_ENV=production
export PORT=5001
node dist/app.js
